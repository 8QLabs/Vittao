<?php

// Access WordPress
require_once( '../../../../../../wp-load.php' );

?>