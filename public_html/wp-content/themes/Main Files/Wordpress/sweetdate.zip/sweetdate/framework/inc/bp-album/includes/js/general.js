jQuery(document).ready( function() {
	// Put your JS in here, and it will run after the DOM has loaded.
	
	// jQuery.post( ajaxurl, {
	// 	action: 'my_example_action',
	// 	'cookie': encodeURIComponent(document.cookie),
	// 	'parameter_1': 'some_value'
	// }, 
	// function(response) { 
	// 	... 
	// } );

});