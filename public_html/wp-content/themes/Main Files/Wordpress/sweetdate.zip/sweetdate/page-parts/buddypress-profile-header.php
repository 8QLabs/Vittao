<!-- PROFILE SECTION
================================================ -->
<section>
  <div id="profile">

    <?php do_action( 'bp_before_member_home_content' ); ?>
    <div class="row">

        <?php locate_template( array( 'members/single/member-header.php' ), true ); ?>

    </div><!--end row-->
  </div><!--end profile-->
</section>
<!--END PROFILE SECTION-->